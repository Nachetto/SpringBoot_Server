package com.hospitalcrud.service;

public class DoctorService {
    // not implemented for this exercise, created on client
}
