package com.hospitalcrud.service;

public class MedicationService {
    // not implemented for this exercise, created on client
}
