package com.hospitalcrud.service;

public class CredentialService {
}
