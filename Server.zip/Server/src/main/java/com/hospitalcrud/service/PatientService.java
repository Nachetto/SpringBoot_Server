package com.hospitalcrud.service;

import com.hospitalcrud.dao.repository.staticDAO.PatientRepository;
import com.hospitalcrud.domain.model.PatientUI;

import java.util.List;
import java.util.stream.Collectors;

public class PatientService {
    private final PatientRepository dao;
    //llamar al DAO inyectado
    public PatientService() {
        this.dao = new PatientRepository();
    }


    public List<PatientUI> getPatients() {
        return dao.getAll().stream().map(p -> p.toPatientUI()).collect(Collectors.toList());
    }

    public int addPatient(PatientUI patientUI) {
        return dao.save(patientUI.toPatient());
    }

    public void updatePatient(PatientUI patientUI) {
        dao.update(patientUI.toPatient());
    }

    public boolean delete(int patientId, boolean confirm) {
        return dao.delete(patientId, confirm);
    }
}
