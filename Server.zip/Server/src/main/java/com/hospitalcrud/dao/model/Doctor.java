package com.hospitalcrud.dao.model;

public class Doctor {
}
