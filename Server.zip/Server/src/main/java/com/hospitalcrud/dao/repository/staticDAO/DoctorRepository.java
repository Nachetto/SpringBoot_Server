package com.hospitalcrud.dao.repository.staticDAO;

public class DoctorRepository {
}
