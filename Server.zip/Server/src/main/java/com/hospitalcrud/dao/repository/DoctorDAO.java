package com.hospitalcrud.dao.repository;

public interface DoctorDAO {
}
